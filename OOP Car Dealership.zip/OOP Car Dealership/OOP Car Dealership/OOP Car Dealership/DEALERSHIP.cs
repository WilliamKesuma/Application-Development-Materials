﻿using System;
using System.Runtime.ConstrainedExecution;


public class Dealership
{
    private string Name;
    public string name
    {
        get { return Name; }
        set { Name = value; }
    }

    private string Location;
    public string location
    {
        get { return Location; }
        set { Location = value; }
    }

    private double Sales;
    public double sales
    {
        get { return Sales; }
        set { Sales = value; }
    }


    List<Car> Cars = new List<Car>();
    List<Sales> CarSales = new List<Sales>();

    public void AddCar(Car car)
    {
        Cars.Add(car);
    }

    public void RemoveCar(string carMake, string carModel)
    {
        foreach (Car random2 in Cars)
        {
            if (random2.make == carMake && random2.model == carModel)
            {
                Cars.Remove(random2);
                break;
            }
        }

    }
    public void PrintCar()
    {
        foreach (var random in Cars)
        {
            Console.WriteLine();
            Console.WriteLine("Car Name: " + random.make);
            Console.WriteLine("Car Year: " + random.year);
            Console.WriteLine("Car Model: " + random.model);
            Console.WriteLine("Car Price: " + random.price);
            Console.WriteLine("Car Type: " + random.type);

            if (random.type == "Electric")
            {
                Console.WriteLine("Car Battery Capacity: " + random.batterycapacity);
            }
            else if (random.type == "Gasoline")
            {
                Console.WriteLine("Car Gastank Size: " + random.gastanksize);
            }
            else
            {
                Console.WriteLine("Car Battery Capacity: " + random.batterycapacity);
                Console.WriteLine("Car Gastank Size: " + random.gastanksize);
                Console.WriteLine();
            }
        }
    }
    public void MakeSale(Sales sale)
    {
        int checker = 0;
        foreach (Car carzz in Cars)
        {
            checker++;
            if (sale.Picked == checker)
            {
                sale.Car = carzz;
                Cars.Remove(carzz);
                break;
            }
        }
        Sales = Sales + sale.Price;
        CarSales.Add(sale);
    }
    public void ViewSale()
    {
        Console.WriteLine("Total Sale Figure: " + Sales);
        foreach (Sales viewsale in CarSales)
        {
            Console.WriteLine("-------------------------");
            Console.WriteLine("Customer:" + viewsale.Customer);
            Console.Write("Make and Model:" + viewsale.Car.make);
            Console.WriteLine(viewsale.Car.model);
            Console.WriteLine("Sale Figures:" + viewsale.Price);
        }
    }
}

