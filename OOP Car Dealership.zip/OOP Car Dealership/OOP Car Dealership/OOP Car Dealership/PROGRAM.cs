﻿using System;

class Program
{
    public static void Main(string[] args)
    {
        Dealership dealership = new Dealership();
        Console.WriteLine("1. Add Dealership Name");
        dealership.name = Console.ReadLine();
        Console.WriteLine();

        Console.WriteLine("2. Add Dealership Location");
        dealership.location = Console.ReadLine();
        Console.WriteLine();

        while (true)
        {
            Car car = new Car();

            int choice2;
            Console.WriteLine("1. Add Car");
            Console.WriteLine("2. Remove Car");
            Console.WriteLine("3. Show Car");
            Console.WriteLine("4. Sell Car");
            Console.WriteLine("5. View Sale");
            Console.WriteLine("6. Exit");
            Console.WriteLine("-----------------------");
            choice2 = Convert.ToInt32(Console.ReadLine());

            if (choice2 == 1)
            {
                Console.WriteLine();
                Console.WriteLine("1. Electric Car");
                Console.WriteLine("2. Hybrid Car");
                Console.WriteLine("3. Gasoline Car");
                Console.WriteLine("-----------------------");
                int choice3;
                choice3 = Convert.ToInt32(Console.ReadLine());

                if (choice3 == 1)
                {

                    Console.WriteLine();
                    Console.WriteLine("Car Name");
                    car.make = Console.ReadLine();
                    Console.WriteLine();

                    Console.WriteLine("Car Model");
                    car.model = (Console.ReadLine());
                    Console.WriteLine();

                    Console.WriteLine("Car Year");
                    car.year = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();

                    Console.WriteLine("Car Price");
                    car.price = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine();

                    Console.WriteLine("Battery Capacity");
                    car.batterycapacity = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();

                    car.type = "Electric";

                    dealership.AddCar(car);
                }

                if (choice3 == 2)
                {
                    Console.WriteLine();
                    Console.WriteLine("Car Name");
                    car.make = Console.ReadLine();
                    Console.WriteLine();

                    Console.WriteLine("Car Model");
                    car.model = (Console.ReadLine());
                    Console.WriteLine();

                    Console.WriteLine("Car Year");
                    car.year = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();

                    Console.WriteLine("Car Price");
                    car.price = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine();

                    Console.WriteLine("Battery Capacity");
                    car.batterycapacity = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();

                    Console.WriteLine("Gas Capacity");
                    car.gastanksize = Convert.ToInt32(Console.ReadLine());

                    car.type = "Hybrid";

                    dealership.AddCar(car);
                }

                if (choice3 == 3)
                {
                    Console.WriteLine();
                    Console.WriteLine("Car Name");
                    car.make = Console.ReadLine();
                    Console.WriteLine();

                    Console.WriteLine("Car Model");
                    car.model = (Console.ReadLine());
                    Console.WriteLine();

                    Console.WriteLine("Car Year");
                    car.year = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();

                    Console.WriteLine("Car Price");
                    car.price = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine();

                    Console.WriteLine("Gas Capacity");
                    car.gastanksize = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();

                    Console.WriteLine("Gas Capacity");
                    car.gastanksize = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine();

                    car.type = "Gasoline";

                    dealership.AddCar(car);
                }

            }
            if (choice2 == 2)
            {
                Console.WriteLine("Car Name: ");
                string make = Console.ReadLine();
                Console.WriteLine();
                Console.WriteLine("Car Model:");
                string model = Console.ReadLine();
                Console.WriteLine();
                dealership.RemoveCar(make, model);
            }

            if (choice2 == 3)
            {
                dealership.PrintCar();

            }
            if (choice2 == 4)
            {
                Sales sale = new Sales();
                dealership.PrintCar();
                Console.WriteLine("Pick from the Catalog, press 0 to return");
                int picked = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Price Paid:");
                sale.Price = Convert.ToDouble(Console.ReadLine());
                if (picked != 0)
                {
                    sale.Picked = picked;
                    Console.WriteLine("Recipient Name:");
                    sale.Customer = Console.ReadLine();
                    dealership.MakeSale(sale);
                }
            }
            if (choice2 == 5)
            {
                Console.Clear();
                dealership.ViewSale();
                Console.ReadKey();
            }
            if (choice2 == 6)
            {
                Console.WriteLine("Program Ended");
                Console.ReadKey();
            }
            Console.ReadKey();
        }
    }
}