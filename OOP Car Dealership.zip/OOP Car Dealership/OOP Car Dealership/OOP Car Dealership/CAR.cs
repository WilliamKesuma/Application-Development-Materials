﻿using System;

public class Car
{
    private string Make;
    public string make
    {
        get { return Make; }
        set { Make = value; }
    }

    private string Model;
    public string model
    {
        get { return Model; }
        set { Model = value; }
    }

    private int Year;
    public int year
    {
        get { return Year; }
        set { Year = value; }
    }

    private double Price;
    public double price
    {
        get { return Price; }
        set { Price = value; }
    }

    private string Type;
    public string type
    {
        get { return Type; }
        set { Type = value; }

    }

    private int GasTankSize;
    public int gastanksize
    {
        get { return GasTankSize; }
        set { GasTankSize = value; }
    }

    private int BatteryCapacity;
    public int batterycapacity
    {
        get { return BatteryCapacity; }
        set { BatteryCapacity = value; }
    }

}
class ElectricCar : Car
{
    private int BatteryCapacity;
    public int batterycapacity
    {
        get { return BatteryCapacity; }
        set { BatteryCapacity = value; }
    }
}

class HybridCar : Car
{
    private int GasTankSize;
    public int gastanksize
    {
        get { return GasTankSize; }
        set { GasTankSize = value; }
    }
    private int BatteryCapacity;
    public int batterycapacity
    {
        get { return BatteryCapacity; }
        set { BatteryCapacity = value; }
    }
}

class GasolineCar : Car
{
    private int GasTankSize;
    public int gastanksize
    {
        get { return GasTankSize; }
        set { GasTankSize = value; }
    }
}



