﻿using System;

public class Sales
{
    protected string customer;
    protected Car car;
    protected double pricepaid;
    protected int picked;

    public string Customer
    {
        get { return customer; }
        set { customer = value; }
    }
    public Car Car
    {
        get { return car; }
        set { car = value; }
    }
    public double Price
    {
        get { return pricepaid; }
        set { pricepaid = value; }
    }
    public int Picked
    {
        get { return picked; }
        set { picked = value; }
    }
}

