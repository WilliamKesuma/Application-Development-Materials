﻿namespace AD_TakeHome_W6
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTN_W = new System.Windows.Forms.Button();
            this.BTN_E = new System.Windows.Forms.Button();
            this.BTN_Q = new System.Windows.Forms.Button();
            this.BTN_R = new System.Windows.Forms.Button();
            this.BTN_T = new System.Windows.Forms.Button();
            this.BTN_Y = new System.Windows.Forms.Button();
            this.BTN_U = new System.Windows.Forms.Button();
            this.BTN_I = new System.Windows.Forms.Button();
            this.BTN_O = new System.Windows.Forms.Button();
            this.BTN_P = new System.Windows.Forms.Button();
            this.BTN_S = new System.Windows.Forms.Button();
            this.BTN_D = new System.Windows.Forms.Button();
            this.BTN_A = new System.Windows.Forms.Button();
            this.BTN_F = new System.Windows.Forms.Button();
            this.BTN_G = new System.Windows.Forms.Button();
            this.BTN_H = new System.Windows.Forms.Button();
            this.BTN_J = new System.Windows.Forms.Button();
            this.BTN_K = new System.Windows.Forms.Button();
            this.BTN_L = new System.Windows.Forms.Button();
            this.BTN_M = new System.Windows.Forms.Button();
            this.BTN_N = new System.Windows.Forms.Button();
            this.BTN_B = new System.Windows.Forms.Button();
            this.BTN_V = new System.Windows.Forms.Button();
            this.BTN_Z = new System.Windows.Forms.Button();
            this.BTN_C = new System.Windows.Forms.Button();
            this.BTN_X = new System.Windows.Forms.Button();
            this.BTN_Delete = new System.Windows.Forms.Button();
            this.BTN_Enter = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BTN_W
            // 
            this.BTN_W.Location = new System.Drawing.Point(457, 71);
            this.BTN_W.Name = "BTN_W";
            this.BTN_W.Size = new System.Drawing.Size(50, 49);
            this.BTN_W.TabIndex = 0;
            this.BTN_W.Tag = "keyboard";
            this.BTN_W.Text = "W";
            this.BTN_W.UseVisualStyleBackColor = true;
            this.BTN_W.Click += new System.EventHandler(this.BTN_W_Click);
            // 
            // BTN_E
            // 
            this.BTN_E.Location = new System.Drawing.Point(507, 71);
            this.BTN_E.Name = "BTN_E";
            this.BTN_E.Size = new System.Drawing.Size(50, 49);
            this.BTN_E.TabIndex = 1;
            this.BTN_E.Tag = "keyboard";
            this.BTN_E.Text = "E";
            this.BTN_E.UseVisualStyleBackColor = true;
            this.BTN_E.Click += new System.EventHandler(this.BTN_E_Click);
            // 
            // BTN_Q
            // 
            this.BTN_Q.Location = new System.Drawing.Point(407, 71);
            this.BTN_Q.Name = "BTN_Q";
            this.BTN_Q.Size = new System.Drawing.Size(50, 49);
            this.BTN_Q.TabIndex = 2;
            this.BTN_Q.Tag = "keyboard";
            this.BTN_Q.Text = "Q";
            this.BTN_Q.UseVisualStyleBackColor = true;
            this.BTN_Q.Click += new System.EventHandler(this.BTN_Q_Click);
            // 
            // BTN_R
            // 
            this.BTN_R.Location = new System.Drawing.Point(557, 71);
            this.BTN_R.Name = "BTN_R";
            this.BTN_R.Size = new System.Drawing.Size(50, 49);
            this.BTN_R.TabIndex = 3;
            this.BTN_R.Tag = "keyboard";
            this.BTN_R.Text = "R";
            this.BTN_R.UseVisualStyleBackColor = true;
            this.BTN_R.Click += new System.EventHandler(this.BTN_R_Click);
            // 
            // BTN_T
            // 
            this.BTN_T.Location = new System.Drawing.Point(607, 71);
            this.BTN_T.Name = "BTN_T";
            this.BTN_T.Size = new System.Drawing.Size(50, 49);
            this.BTN_T.TabIndex = 4;
            this.BTN_T.Tag = "keyboard";
            this.BTN_T.Text = "T";
            this.BTN_T.UseVisualStyleBackColor = true;
            this.BTN_T.Click += new System.EventHandler(this.BTN_T_Click);
            // 
            // BTN_Y
            // 
            this.BTN_Y.Location = new System.Drawing.Point(657, 71);
            this.BTN_Y.Name = "BTN_Y";
            this.BTN_Y.Size = new System.Drawing.Size(50, 49);
            this.BTN_Y.TabIndex = 5;
            this.BTN_Y.Tag = "keyboard";
            this.BTN_Y.Text = "Y";
            this.BTN_Y.UseVisualStyleBackColor = true;
            this.BTN_Y.Click += new System.EventHandler(this.BTN_Y_Click);
            // 
            // BTN_U
            // 
            this.BTN_U.Location = new System.Drawing.Point(707, 71);
            this.BTN_U.Name = "BTN_U";
            this.BTN_U.Size = new System.Drawing.Size(50, 49);
            this.BTN_U.TabIndex = 6;
            this.BTN_U.Tag = "keyboard";
            this.BTN_U.Text = "U";
            this.BTN_U.UseVisualStyleBackColor = true;
            this.BTN_U.Click += new System.EventHandler(this.BTN_U_Click);
            // 
            // BTN_I
            // 
            this.BTN_I.Location = new System.Drawing.Point(757, 71);
            this.BTN_I.Name = "BTN_I";
            this.BTN_I.Size = new System.Drawing.Size(50, 49);
            this.BTN_I.TabIndex = 7;
            this.BTN_I.Tag = "keyboard";
            this.BTN_I.Text = "I";
            this.BTN_I.UseVisualStyleBackColor = true;
            this.BTN_I.Click += new System.EventHandler(this.BTN_I_Click);
            // 
            // BTN_O
            // 
            this.BTN_O.Location = new System.Drawing.Point(807, 71);
            this.BTN_O.Name = "BTN_O";
            this.BTN_O.Size = new System.Drawing.Size(50, 49);
            this.BTN_O.TabIndex = 8;
            this.BTN_O.Tag = "keyboard";
            this.BTN_O.Text = "O";
            this.BTN_O.UseVisualStyleBackColor = true;
            this.BTN_O.Click += new System.EventHandler(this.BTN_O_Click);
            // 
            // BTN_P
            // 
            this.BTN_P.Location = new System.Drawing.Point(857, 71);
            this.BTN_P.Name = "BTN_P";
            this.BTN_P.Size = new System.Drawing.Size(50, 49);
            this.BTN_P.TabIndex = 9;
            this.BTN_P.Tag = "keyboard";
            this.BTN_P.Text = "P";
            this.BTN_P.UseVisualStyleBackColor = true;
            this.BTN_P.Click += new System.EventHandler(this.BTN_P_Click);
            // 
            // BTN_S
            // 
            this.BTN_S.Location = new System.Drawing.Point(484, 126);
            this.BTN_S.Name = "BTN_S";
            this.BTN_S.Size = new System.Drawing.Size(50, 49);
            this.BTN_S.TabIndex = 10;
            this.BTN_S.Tag = "keyboard";
            this.BTN_S.Text = "S";
            this.BTN_S.UseVisualStyleBackColor = true;
            this.BTN_S.Click += new System.EventHandler(this.BTN_S_Click);
            // 
            // BTN_D
            // 
            this.BTN_D.Location = new System.Drawing.Point(534, 126);
            this.BTN_D.Name = "BTN_D";
            this.BTN_D.Size = new System.Drawing.Size(50, 49);
            this.BTN_D.TabIndex = 11;
            this.BTN_D.Tag = "keyboard";
            this.BTN_D.Text = "D";
            this.BTN_D.UseVisualStyleBackColor = true;
            this.BTN_D.Click += new System.EventHandler(this.BTN_D_Click);
            // 
            // BTN_A
            // 
            this.BTN_A.Location = new System.Drawing.Point(434, 126);
            this.BTN_A.Name = "BTN_A";
            this.BTN_A.Size = new System.Drawing.Size(50, 49);
            this.BTN_A.TabIndex = 12;
            this.BTN_A.Tag = "keyboard";
            this.BTN_A.Text = "A";
            this.BTN_A.UseVisualStyleBackColor = true;
            this.BTN_A.Click += new System.EventHandler(this.BTN_A_Click);
            // 
            // BTN_F
            // 
            this.BTN_F.Location = new System.Drawing.Point(584, 126);
            this.BTN_F.Name = "BTN_F";
            this.BTN_F.Size = new System.Drawing.Size(50, 49);
            this.BTN_F.TabIndex = 13;
            this.BTN_F.Tag = "keyboard";
            this.BTN_F.Text = "F";
            this.BTN_F.UseVisualStyleBackColor = true;
            this.BTN_F.Click += new System.EventHandler(this.BTN_F_Click);
            // 
            // BTN_G
            // 
            this.BTN_G.Location = new System.Drawing.Point(634, 126);
            this.BTN_G.Name = "BTN_G";
            this.BTN_G.Size = new System.Drawing.Size(50, 49);
            this.BTN_G.TabIndex = 14;
            this.BTN_G.Tag = "keyboard";
            this.BTN_G.Text = "G";
            this.BTN_G.UseVisualStyleBackColor = true;
            this.BTN_G.Click += new System.EventHandler(this.BTN_G_Click);
            // 
            // BTN_H
            // 
            this.BTN_H.Location = new System.Drawing.Point(684, 126);
            this.BTN_H.Name = "BTN_H";
            this.BTN_H.Size = new System.Drawing.Size(50, 49);
            this.BTN_H.TabIndex = 15;
            this.BTN_H.Tag = "keyboard";
            this.BTN_H.Text = "H";
            this.BTN_H.UseVisualStyleBackColor = true;
            this.BTN_H.Click += new System.EventHandler(this.BTN_H_Click);
            // 
            // BTN_J
            // 
            this.BTN_J.Location = new System.Drawing.Point(734, 126);
            this.BTN_J.Name = "BTN_J";
            this.BTN_J.Size = new System.Drawing.Size(50, 49);
            this.BTN_J.TabIndex = 16;
            this.BTN_J.Tag = "keyboard";
            this.BTN_J.Text = "J";
            this.BTN_J.UseVisualStyleBackColor = true;
            this.BTN_J.Click += new System.EventHandler(this.BTN_J_Click);
            // 
            // BTN_K
            // 
            this.BTN_K.Location = new System.Drawing.Point(784, 126);
            this.BTN_K.Name = "BTN_K";
            this.BTN_K.Size = new System.Drawing.Size(50, 49);
            this.BTN_K.TabIndex = 17;
            this.BTN_K.Tag = "keyboard";
            this.BTN_K.Text = "K";
            this.BTN_K.UseVisualStyleBackColor = true;
            this.BTN_K.Click += new System.EventHandler(this.BTN_K_Click);
            // 
            // BTN_L
            // 
            this.BTN_L.Location = new System.Drawing.Point(834, 126);
            this.BTN_L.Name = "BTN_L";
            this.BTN_L.Size = new System.Drawing.Size(50, 49);
            this.BTN_L.TabIndex = 18;
            this.BTN_L.Tag = "keyboard";
            this.BTN_L.Text = "L";
            this.BTN_L.UseVisualStyleBackColor = true;
            this.BTN_L.Click += new System.EventHandler(this.BTN_L_Click);
            // 
            // BTN_M
            // 
            this.BTN_M.Location = new System.Drawing.Point(757, 181);
            this.BTN_M.Name = "BTN_M";
            this.BTN_M.Size = new System.Drawing.Size(50, 49);
            this.BTN_M.TabIndex = 25;
            this.BTN_M.Tag = "keyboard";
            this.BTN_M.Text = "M";
            this.BTN_M.UseVisualStyleBackColor = true;
            this.BTN_M.Click += new System.EventHandler(this.BTN_M_Click);
            // 
            // BTN_N
            // 
            this.BTN_N.Location = new System.Drawing.Point(707, 181);
            this.BTN_N.Name = "BTN_N";
            this.BTN_N.Size = new System.Drawing.Size(50, 49);
            this.BTN_N.TabIndex = 24;
            this.BTN_N.Tag = "keyboard";
            this.BTN_N.Text = "N";
            this.BTN_N.UseVisualStyleBackColor = true;
            this.BTN_N.Click += new System.EventHandler(this.BTN_N_Click);
            // 
            // BTN_B
            // 
            this.BTN_B.Location = new System.Drawing.Point(657, 181);
            this.BTN_B.Name = "BTN_B";
            this.BTN_B.Size = new System.Drawing.Size(50, 49);
            this.BTN_B.TabIndex = 23;
            this.BTN_B.Tag = "keyboard";
            this.BTN_B.Text = "B";
            this.BTN_B.UseVisualStyleBackColor = true;
            this.BTN_B.Click += new System.EventHandler(this.BTN_B_Click);
            // 
            // BTN_V
            // 
            this.BTN_V.Location = new System.Drawing.Point(607, 181);
            this.BTN_V.Name = "BTN_V";
            this.BTN_V.Size = new System.Drawing.Size(50, 49);
            this.BTN_V.TabIndex = 22;
            this.BTN_V.Tag = "keyboard";
            this.BTN_V.Text = "V";
            this.BTN_V.UseVisualStyleBackColor = true;
            this.BTN_V.Click += new System.EventHandler(this.BTN_V_Click);
            // 
            // BTN_Z
            // 
            this.BTN_Z.Location = new System.Drawing.Point(457, 181);
            this.BTN_Z.Name = "BTN_Z";
            this.BTN_Z.Size = new System.Drawing.Size(50, 49);
            this.BTN_Z.TabIndex = 21;
            this.BTN_Z.Tag = "keyboard";
            this.BTN_Z.Text = "Z";
            this.BTN_Z.UseVisualStyleBackColor = true;
            this.BTN_Z.Click += new System.EventHandler(this.BTN_Z_Click);
            // 
            // BTN_C
            // 
            this.BTN_C.Location = new System.Drawing.Point(557, 181);
            this.BTN_C.Name = "BTN_C";
            this.BTN_C.Size = new System.Drawing.Size(50, 49);
            this.BTN_C.TabIndex = 20;
            this.BTN_C.Tag = "keyboard";
            this.BTN_C.Text = "C";
            this.BTN_C.UseVisualStyleBackColor = true;
            this.BTN_C.Click += new System.EventHandler(this.BTN_C_Click);
            // 
            // BTN_X
            // 
            this.BTN_X.Location = new System.Drawing.Point(507, 181);
            this.BTN_X.Name = "BTN_X";
            this.BTN_X.Size = new System.Drawing.Size(50, 49);
            this.BTN_X.TabIndex = 19;
            this.BTN_X.Tag = "keyboard";
            this.BTN_X.Text = "X";
            this.BTN_X.UseVisualStyleBackColor = true;
            this.BTN_X.Click += new System.EventHandler(this.BTN_X_Click);
            // 
            // BTN_Delete
            // 
            this.BTN_Delete.Location = new System.Drawing.Point(407, 260);
            this.BTN_Delete.Name = "BTN_Delete";
            this.BTN_Delete.Size = new System.Drawing.Size(77, 49);
            this.BTN_Delete.TabIndex = 26;
            this.BTN_Delete.Tag = "keyboard";
            this.BTN_Delete.Text = "Delete";
            this.BTN_Delete.UseVisualStyleBackColor = true;
            this.BTN_Delete.Click += new System.EventHandler(this.BTN_Delete_Click);
            // 
            // BTN_Enter
            // 
            this.BTN_Enter.Location = new System.Drawing.Point(807, 260);
            this.BTN_Enter.Name = "BTN_Enter";
            this.BTN_Enter.Size = new System.Drawing.Size(100, 49);
            this.BTN_Enter.TabIndex = 27;
            this.BTN_Enter.Tag = "keyboard";
            this.BTN_Enter.Text = "Enter";
            this.BTN_Enter.UseVisualStyleBackColor = true;
            this.BTN_Enter.Click += new System.EventHandler(this.BTN_Enter_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(943, 450);
            this.Controls.Add(this.BTN_Enter);
            this.Controls.Add(this.BTN_Delete);
            this.Controls.Add(this.BTN_M);
            this.Controls.Add(this.BTN_N);
            this.Controls.Add(this.BTN_B);
            this.Controls.Add(this.BTN_V);
            this.Controls.Add(this.BTN_Z);
            this.Controls.Add(this.BTN_C);
            this.Controls.Add(this.BTN_X);
            this.Controls.Add(this.BTN_L);
            this.Controls.Add(this.BTN_K);
            this.Controls.Add(this.BTN_J);
            this.Controls.Add(this.BTN_H);
            this.Controls.Add(this.BTN_G);
            this.Controls.Add(this.BTN_F);
            this.Controls.Add(this.BTN_A);
            this.Controls.Add(this.BTN_D);
            this.Controls.Add(this.BTN_S);
            this.Controls.Add(this.BTN_P);
            this.Controls.Add(this.BTN_O);
            this.Controls.Add(this.BTN_I);
            this.Controls.Add(this.BTN_U);
            this.Controls.Add(this.BTN_Y);
            this.Controls.Add(this.BTN_T);
            this.Controls.Add(this.BTN_R);
            this.Controls.Add(this.BTN_Q);
            this.Controls.Add(this.BTN_E);
            this.Controls.Add(this.BTN_W);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BTN_W;
        private System.Windows.Forms.Button BTN_E;
        private System.Windows.Forms.Button BTN_Q;
        private System.Windows.Forms.Button BTN_R;
        private System.Windows.Forms.Button BTN_T;
        private System.Windows.Forms.Button BTN_Y;
        private System.Windows.Forms.Button BTN_U;
        private System.Windows.Forms.Button BTN_I;
        private System.Windows.Forms.Button BTN_O;
        private System.Windows.Forms.Button BTN_P;
        private System.Windows.Forms.Button BTN_S;
        private System.Windows.Forms.Button BTN_D;
        private System.Windows.Forms.Button BTN_A;
        private System.Windows.Forms.Button BTN_F;
        private System.Windows.Forms.Button BTN_G;
        private System.Windows.Forms.Button BTN_H;
        private System.Windows.Forms.Button BTN_J;
        private System.Windows.Forms.Button BTN_K;
        private System.Windows.Forms.Button BTN_L;
        private System.Windows.Forms.Button BTN_M;
        private System.Windows.Forms.Button BTN_N;
        private System.Windows.Forms.Button BTN_B;
        private System.Windows.Forms.Button BTN_V;
        private System.Windows.Forms.Button BTN_Z;
        private System.Windows.Forms.Button BTN_C;
        private System.Windows.Forms.Button BTN_X;
        private System.Windows.Forms.Button BTN_Delete;
        private System.Windows.Forms.Button BTN_Enter;
    }
}