﻿namespace AD_TakeHome_W6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TB_Input = new System.Windows.Forms.TextBox();
            this.BTN_Play = new System.Windows.Forms.Button();
            this.WORDLE = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TB_Input
            // 
            this.TB_Input.Location = new System.Drawing.Point(266, 185);
            this.TB_Input.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TB_Input.Name = "TB_Input";
            this.TB_Input.Size = new System.Drawing.Size(220, 31);
            this.TB_Input.TabIndex = 0;
            // 
            // BTN_Play
            // 
            this.BTN_Play.Location = new System.Drawing.Point(316, 269);
            this.BTN_Play.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.BTN_Play.Name = "BTN_Play";
            this.BTN_Play.Size = new System.Drawing.Size(130, 44);
            this.BTN_Play.TabIndex = 1;
            this.BTN_Play.Text = "Play";
            this.BTN_Play.UseVisualStyleBackColor = true;
            this.BTN_Play.Click += new System.EventHandler(this.BTN_Play_Click);
            // 
            // WORDLE
            // 
            this.WORDLE.AutoSize = true;
            this.WORDLE.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WORDLE.Location = new System.Drawing.Point(222, 63);
            this.WORDLE.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.WORDLE.Name = "WORDLE";
            this.WORDLE.Size = new System.Drawing.Size(313, 73);
            this.WORDLE.TabIndex = 2;
            this.WORDLE.Text = "WORDLE";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(261, 136);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(239, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Type a number above 3";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(768, 469);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.WORDLE);
            this.Controls.Add(this.BTN_Play);
            this.Controls.Add(this.TB_Input);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TB_Input;
        private System.Windows.Forms.Button BTN_Play;
        private System.Windows.Forms.Label WORDLE;
        private System.Windows.Forms.Label label1;
    }
}

