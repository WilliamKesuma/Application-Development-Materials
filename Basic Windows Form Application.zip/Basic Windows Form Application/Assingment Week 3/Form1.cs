﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Assingment_Week_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BTN_Submit_Click(object sender, EventArgs e)
        {
            string name = "Name: " + TB_Name.Text;
            string age = "Age: " + TB_Age.Text;
            string email = "Email: " + TB_Email.Text;
            string Phone = "Phone Number: " + TB_Phonenum.Text;
            int parsedValue;
            if (!int.TryParse(TB_Age.Text, out parsedValue))
            {
                MessageBox.Show("please insert only number in the age textbox");
            }
            else
            { 
                if (Convert.ToInt32(TB_Age.Text) < 18)
                {
                    MessageBox.Show(name + "\n" + age + "\n" + email + "\n" + Phone + "\n" + TB_Name.Text + " is a minor");
                }
                else
                {
                    MessageBox.Show(name + "\n" + age + "\n" + email + "\n" + Phone + "\n" + TB_Name.Text + " is not a minor");
                }
            }
        }

        private void BTN_Clear_Click(object sender, EventArgs e)
        {
            TB_Name.Text = "";
            TB_Age.Text = "";
            TB_Email.Text = "";
            TB_Phonenum.Text = "";

        }
    }
}
