﻿using System.Reflection.Emit;

namespace Assingment_Week_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Name = new System.Windows.Forms.Label();
            this.Age = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.Phone_Num = new System.Windows.Forms.Label();
            this.TB_Name = new System.Windows.Forms.TextBox();
            this.TB_Age = new System.Windows.Forms.TextBox();
            this.TB_Email = new System.Windows.Forms.TextBox();
            this.TB_Phonenum = new System.Windows.Forms.TextBox();
            this.BTN_Submit = new System.Windows.Forms.Button();
            this.BTN_Clear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Name
            // 
            this.Name.AutoSize = true;
            this.Name.Location = new System.Drawing.Point(183, 69);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(35, 13);
            this.Name.TabIndex = 0;
            this.Name.Text = "Name";
            // 
            // Age
            // 
            this.Age.AutoSize = true;
            this.Age.Location = new System.Drawing.Point(183, 110);
            this.Age.Name = "Age";
            this.Age.Size = new System.Drawing.Size(26, 13);
            this.Age.TabIndex = 1;
            this.Age.Text = "Age";
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(183, 151);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(32, 13);
            this.Email.TabIndex = 2;
            this.Email.Text = "Email";
            // 
            // Phone_Num
            // 
            this.Phone_Num.AutoSize = true;
            this.Phone_Num.Location = new System.Drawing.Point(183, 197);
            this.Phone_Num.Name = "Phone_Num";
            this.Phone_Num.Size = new System.Drawing.Size(78, 13);
            this.Phone_Num.TabIndex = 3;
            this.Phone_Num.Text = "Phone Number";
            // 
            // TB_Name
            // 
            this.TB_Name.Location = new System.Drawing.Point(294, 66);
            this.TB_Name.Name = "TB_Name";
            this.TB_Name.Size = new System.Drawing.Size(100, 20);
            this.TB_Name.TabIndex = 4;
            // 
            // TB_Age
            // 
            this.TB_Age.Location = new System.Drawing.Point(294, 107);
            this.TB_Age.Name = "TB_Age";
            this.TB_Age.Size = new System.Drawing.Size(100, 20);
            this.TB_Age.TabIndex = 5;
            // 
            // TB_Email
            // 
            this.TB_Email.Location = new System.Drawing.Point(294, 148);
            this.TB_Email.Name = "TB_Email";
            this.TB_Email.Size = new System.Drawing.Size(100, 20);
            this.TB_Email.TabIndex = 6;
            // 
            // TB_Phonenum
            // 
            this.TB_Phonenum.Location = new System.Drawing.Point(294, 194);
            this.TB_Phonenum.Name = "TB_Phonenum";
            this.TB_Phonenum.Size = new System.Drawing.Size(100, 20);
            this.TB_Phonenum.TabIndex = 7;
            // 
            // BTN_Submit
            // 
            this.BTN_Submit.BackColor = System.Drawing.SystemColors.Info;
            this.BTN_Submit.Location = new System.Drawing.Point(294, 265);
            this.BTN_Submit.Name = "BTN_Submit";
            this.BTN_Submit.Size = new System.Drawing.Size(75, 23);
            this.BTN_Submit.TabIndex = 8;
            this.BTN_Submit.Text = "Submit";
            this.BTN_Submit.UseVisualStyleBackColor = false;
            this.BTN_Submit.Click += new System.EventHandler(this.BTN_Submit_Click);
            // 
            // BTN_Clear
            // 
            this.BTN_Clear.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.BTN_Clear.Location = new System.Drawing.Point(186, 265);
            this.BTN_Clear.Name = "BTN_Clear";
            this.BTN_Clear.Size = new System.Drawing.Size(75, 23);
            this.BTN_Clear.TabIndex = 9;
            this.BTN_Clear.Text = "Clear";
            this.BTN_Clear.UseVisualStyleBackColor = false;
            this.BTN_Clear.Click += new System.EventHandler(this.BTN_Clear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(663, 417);
            this.Controls.Add(this.BTN_Clear);
            this.Controls.Add(this.BTN_Submit);
            this.Controls.Add(this.TB_Phonenum);
            this.Controls.Add(this.TB_Email);
            this.Controls.Add(this.TB_Age);
            this.Controls.Add(this.TB_Name);
            this.Controls.Add(this.Phone_Num);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Age);
            this.Controls.Add(this.Name);
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Name;
        private System.Windows.Forms.Label Age;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.Label Phone_Num;
        private System.Windows.Forms.TextBox TB_Name;
        private System.Windows.Forms.TextBox TB_Age;
        private System.Windows.Forms.TextBox TB_Email;
        private System.Windows.Forms.TextBox TB_Phonenum;
        private System.Windows.Forms.Button BTN_Submit;
        private System.Windows.Forms.Button BTN_Clear;
    }
}

